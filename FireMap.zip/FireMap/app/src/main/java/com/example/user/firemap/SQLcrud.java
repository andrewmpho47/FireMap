package com.example.user.firemap;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SQLcrud extends AppCompatActivity {
    EditText firstname,lastname;
    TextView textView;
    DB_Controller controller;
    Button update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlcrud);

        firstname = (EditText)findViewById(R.id.Firstname_input);
        lastname = (EditText) findViewById(R.id.Lastname_input);
        textView = (TextView) findViewById(R.id.textView);

        // Link to Forget Password Screen
        findViewById(R.id.forget_password_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class).putExtra("Mode", 0));
            }
        });


        controller = new DB_Controller(this,"",null,1);

    }

    public void btn_click(View view) {
        switch (view.getId()){
            case R.id.button_add:
                try{
                    controller.insert_student(firstname.getText().toString(),lastname.getText().toString());


                }catch (SQLiteException e){
                    Toast.makeText(SQLcrud.this,"ALREADY EXISTS",Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.btn_delete:
                controller.delete_student(firstname.getText().toString());
                break;

           /* case R.id.btn_update:
                setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(SQLcrud.this, MainActivity.class));
                        finish();
                    }
                });
                AlertDialog.Builder dialog = new AlertDialog.Builder(SQLcrud.this);
                dialog.setTitle("Enter New");

                final EditText new_firstname = new EditText(this);
                dialog.setView(new_firstname);

                dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        controller.update_student(firstname.getText().toString(),new_firstname.getText().toString());

                    }
                });

                dialog.show();


                break;*/
            case R.id.list_student:
                controller.list_all_students(textView);
                break;

        }
    }
}
